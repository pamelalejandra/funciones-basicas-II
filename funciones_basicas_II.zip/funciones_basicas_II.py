#1.Cuenta regresiva:
def cuenta_regresiva( num ):
    resultado = []
    
    for i in range( num, -1, -1 ):
        resultado.append( i )
    return resultado

lista = cuenta_regresiva( 5 )
print( lista )

print("---")

#2.Imprimir y devolver:
def imprimir_devolver(lista):
    print(lista[0])
    return lista[1]

resultado = imprimir_devolver([1,2])

print("---")

#3.Primero mas longitud:
def primero_mas_longitud(lista):
    resultado = lista[0] + len(lista)
    return resultado

resultado = primero_mas_longitud([1,2,3])
print(resultado)

print("---")

#4.Valores mayores que el segundo
def mayores_que_segundo( lista ):
    resultado = []

    if len( lista ) >= 2:
        for numero in lista:
            if numero > lista[1]:
                resultado.append( numero )

    print( len( resultado ) )
    if len( resultado ) < 2:
        return False
    else:
        return resultado

lista1 = mayores_que_segundo( [5, 2, 3, 2, 1, 4] )
print( lista1 )
lista2 = mayores_que_segundo( [3] )
print( lista2 )

print("---")

#5.Longitud
def longitud(tamaño, valor):
    lista = []
    for i in range (tamaño):
        lista.append(valor)
    return lista
print(longitud(2,9))